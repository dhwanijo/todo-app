prompt = "Enter the title: "
text = input(prompt)
length_of_title = len(text)
print("The length of the title:", length_of_title)
