password = input ("Enter a password: ")

while password != "pass123":
    password = input("Enter a password: ")

print("Password was correct ")